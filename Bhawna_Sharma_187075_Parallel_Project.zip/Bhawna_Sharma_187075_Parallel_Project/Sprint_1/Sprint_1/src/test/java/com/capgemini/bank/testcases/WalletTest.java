package com.capgemini.bank.testcases;

import static org.junit.jupiter.api.Assertions.*;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.exceptions.*;
import com.capgemini.bank.service.AccountService;
import com.capgemini.bank.service.AccountServiceImpl;

@TestInstance(Lifecycle.PER_CLASS)
class WalletTest {
	AccountService service;
	@BeforeAll
	void intialize(){
		service=new AccountServiceImpl();
	}
	
	@Test
	void testCreateAccount() throws InvalidMailException, InvalidPhoneNumberException
	{
		Account user=new Account();
		user.setName("Bhawna");
		user.setPhoneNumber(9876543210L);
		user.setBalance(2000);
		user.setEmailid("bhawna1877@gmail.com");
		String string=service.createAccount(user);
		assertNotEquals(null, string);
	}
	
	@Test
	void testaddMoney() throws AccountNotFoundException{
		Account user=new Account();
		String accountNumber=null;
		Map<String, Account> userlist=new HashMap<String, Account>();
		userlist=service.getAllAccounts();
		Set<Entry<String, Account>> set=userlist.entrySet();
		Iterator<Entry<String, Account>> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String, Account> me=(Map.Entry<String, Account>)i.next();
			accountNumber=me.getKey();
			user=me.getValue();
		}
		if(service.addMoney(accountNumber, 5000))
		{
			assertTrue(true);
		}
		else
		{
			assertFalse(false);
		}
	}
	
	@Test
	void testTransfer() throws InvalidMailException , InvalidPhoneNumberException, InsuffecientBalanceException, AccountNotFoundException, SameAccountException
	{
		Account user=new Account();
		List<String> list=new ArrayList<String>();
		user.setName("Mudit");
		user.setPhoneNumber(8898898890L);
		user.setEmailid("Mudit998@gmail.com");
		user.setBalance(0);
		service.createAccount(user);
		Map<String, Account> userlist=new HashMap<String, Account>();
		userlist=service.getAllAccounts();
		Set<Entry<String, Account>> set=userlist.entrySet();
		Iterator<Entry<String, Account>> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String, Account> me=(Map.Entry<String, Account>)i.next();
			list.add(me.getKey());
		}
		if(service.transfer(list.get(0), list.get(1), 1000))
		{
			assertTrue(true);
		}
		else
		{
			assertFalse(false);
		}
	}
	
}
