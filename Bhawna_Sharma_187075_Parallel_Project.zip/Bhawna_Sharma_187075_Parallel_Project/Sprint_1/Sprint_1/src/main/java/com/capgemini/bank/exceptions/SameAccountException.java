package com.capgemini.bank.exceptions;
@SuppressWarnings("serial")
public class SameAccountException extends Exception {
	public SameAccountException()
	{
		super("The Entered Account Number Are Same.");
	}

}
