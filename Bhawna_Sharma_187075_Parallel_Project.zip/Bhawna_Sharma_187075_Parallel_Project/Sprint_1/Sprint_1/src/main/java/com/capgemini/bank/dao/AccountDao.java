package com.capgemini.bank.dao;

import java.util.HashMap;


import com.capgemini.bank.bean.Account;
import com.capgemini.bank.exceptions.*;

public interface AccountDao {
	public void createAccount(String accountNumber, Account user);
	public Account viewAccount(String accountNumber) throws AccountNotFoundException;
	public boolean addMoney(String accountNumber, int amount) throws AccountNotFoundException;
	public boolean transfer(String accountNumber1,String accountNumber2, int amount) throws SameAccountException,InsuffecientBalanceException, AccountNotFoundException;
	public HashMap<String, Account> getAllAccounts();
	

}
