package com.capgemini.bank.userinterface;

import java.util.HashMap;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.service.AccountServiceImpl;



public class Start {
	static AccountServiceImpl service=new AccountServiceImpl();
	public static void showMenu() {
		System.out.println("                        ****** WELCOME TO THE BANK ******");
		System.out.println("");
		System.out.println("---------------------------------------------------");
		System.out.println("1. Account Creation");
		System.out.println("");
		System.out.println("2. Add Money To The Account");
		System.out.println("");
		System.out.println("3. Show The Details");
		System.out.println("");
		System.out.println("4. Transfer Money To Another Account");
		System.out.println("");
		System.out.println("5. Show Detail Of All The Accounts");
		System.out.println("");
		System.out.println("6. EXIT");
		System.out.println("---------------------------------------------------");
		System.out.print("Please Enter Your Choice :- ");
	}
	public static void main(String[] args) {
		@SuppressWarnings("RESOURCES")
		Scanner scanner = new Scanner(System.in);
		boolean result;
		int choice;
		while(true)
		{
			showMenu();
			choice = scanner.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Creation Of The Account");
				try
				{
					Account user=new Account();
					System.out.println("Please Enter Your Name : ");
					user.setName(scanner.next());
					System.out.println("Please Enter Your Mobile Number : ");
					user.setPhoneNumber(scanner.nextLong());
					System.out.println("Please Enter Your EmailId : ");
					user.setEmailid(scanner.next());
					user.setBalance(0);
					String AccountNumber=service.createAccount(user);
					System.out.println("Account Number Is : "+AccountNumber);
					
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 2:
				result=false;
				System.out.println("Add Money");
				try {
					System.out.println("Please Enter The Account Number To Add Money : ");
					String AccountNumber=scanner.next();
					System.out.println("Please Enter The Amount To Add Money : "+AccountNumber);
					int Amount=scanner.nextInt();
					result=service.addMoney(AccountNumber, Amount);
					if(result) {
						System.out.println("Amount Added Successfully!");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 3:
				System.out.println("View The Account Details");
				try
				{
					System.out.println("Please Enter The Account Number");
					String AccountNumber=scanner.next();
					Account user=service.viewAccount(AccountNumber);
					System.out.println("UserName : "+user.getName()+"\nPhoneNumber : "+user.getPhoneNumber()+"\nEmailId : "+user.getEmailid()+"\nBalance : "+user.getBalance());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				result=false;
				System.out.println("Money Transaction");
				try
				{
					System.out.println("Enter The Source Account Number : ");
					String SenderAccountNumber=scanner.next();
					System.out.println("Enter The Destination Account Number : ");
					String RecieverAccountNumber=scanner.next();
					System.out.println("Enter The Amount To Be Transferred : ");
					int TransferAmount=scanner.nextInt();
					result=service.transfer(SenderAccountNumber, RecieverAccountNumber, TransferAmount);
					if(result) {
						System.out.println("Money Transfered Successfully!");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 5:
				try
				{
					Map<String, Account> userlist=new HashMap<String, Account>();
					userlist=service.getAllAccounts();
					if(!userlist.isEmpty())
					{

						Set<Entry<String, Account>> set=userlist.entrySet();
						Iterator<Entry<String, Account>> i=set.iterator();
						while(i.hasNext())
						{
							Map.Entry<String, Account> me=(Map.Entry<String, Account>)i.next();
							Account account=me.getValue();
							System.out.println("AccountNumber : "+me.getKey()+"\nName : "+account.getName());
						}
					}
					else
					{
						System.out.println("No Such Accounts Found");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 6:
				System.exit(0);
			default:
				break;
			}
		}
	}

}
