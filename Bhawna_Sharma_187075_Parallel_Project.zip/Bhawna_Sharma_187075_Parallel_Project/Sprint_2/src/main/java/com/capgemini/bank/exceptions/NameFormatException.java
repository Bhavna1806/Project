package com.capgemini.bank.exceptions;
@SuppressWarnings("serial")
public class NameFormatException extends Exception{
	public NameFormatException()
	{
		super("Name Format Is Incorrect. Enter The First Letter In Uppercase");
	}

}
