package com.capgemini.bank.testcases;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.SQLException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.capgemini.bank.bean.Account;
import com.capgemini.bank.service.AccountService;
import com.capgemini.bank.service.AccountServiceImpl;

@TestInstance(Lifecycle.PER_CLASS)
class WalletTest {
	AccountService service;
	String string=null;
	@BeforeAll
	void intialize(){
		service=new AccountServiceImpl();
	}
	
	@Test
	void testCreateAccount() throws SQLException, Exception
	{
		Account user=new Account();
		user.setName("Bhawna");
		user.setPhoneNumber(9876543210L);
		user.setBalance(2000);
		user.setEmailid("bhawna1877@gmail.com");
		string=service.createAccount(user);
		assertNotEquals(null, string);
	}
	
	@Test
	void testaddMoney() throws SQLException, Exception{
		if(service.addMoney(string, 5000))
		{
			assertTrue(true);
		}
		else
		{
			assertFalse(false);
		}
	}
	
	@Test
	void testTransfer() throws Exception
	{
		Account user=new Account();
		user.setName("Mudit");
		user.setPhoneNumber(8898898890L);
		user.setEmailid("Mudit98@gmail.com");
		user.setBalance(0);
		String newstring=service.createAccount(user);
		if(service.transfer(string, newstring, 1000))
		{
			assertTrue(true);
		}
		else
		{
			assertFalse(false);
		}
	}
	
}
