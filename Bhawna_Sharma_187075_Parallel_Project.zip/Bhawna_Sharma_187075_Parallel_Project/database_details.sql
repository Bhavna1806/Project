create database newdb;
use newdb;
create table details(
AccNumber varchar(10) primary key,
name varchar(20),
phNumber bigint(10),
email varchar(20),
balance int(5)
);

select * from details;



