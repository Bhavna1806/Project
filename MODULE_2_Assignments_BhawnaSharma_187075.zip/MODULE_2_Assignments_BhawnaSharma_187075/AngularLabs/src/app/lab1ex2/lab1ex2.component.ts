import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab1ex2',
  templateUrl: './lab1ex2.component.html',
  styleUrls: ['./lab1ex2.component.css']
})
export class Lab1ex2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  display(id,name,salary,department)
  {
    alert("Id:"+id+" name:"+name+" salary:"+salary+" department:"+department)
  }

}
