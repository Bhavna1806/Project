import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab3',
  templateUrl: './lab3.component.html',
  styleUrls: ['./lab3.component.css']
})
export class Lab3Component implements OnInit {
  idValidation=false
  nameValidation=false
  pcValidation=false
  rValidation=false
  pcatValidation=false
  storeValidation=false
  constructor() { }

  ngOnInit() {
  }
  add(form)
  {
    if(!form.pid)
    {
      this.idValidation=true
      return
    }
    else{
      this.idValidation=false
    }
    if(!form.pname)
    {
      this.nameValidation=true
      return
    }
    else
    {
      this.nameValidation=false
    }
    if(!form.pcost)
    {
      this.pcValidation=true
      return
    }
    else{
      this.pcValidation=false
    }
    if(!form.pponline)
    {
      console.log(form.pponline)
      this.rValidation=true
      return
    }
    else
    {
      this.rValidation=false
    }
    if(!form.pcat)
    {
     
      this.pcatValidation=true
      return
    }
    else
    {
      this.pcatValidation=false
    }
    
  console.log(form.pid)
  console.log(form.pname)
  console.log(form.pcost)
  console.log(form.pponline)
  console.log(form.pcat)
  if(form.bigbazar==true)
      console.log("Big Bazar")
    if(form.dmart==true)
      console.log("DMart")
    if(form.reliance==true)
      console.log("Reliance")
    if(form.megastore==true)
      console.log("Mega Store")
  }
  

}
