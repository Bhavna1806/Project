import{Mobile} from './mobile';

export class Smartphone extends Mobile{
    mobileType:string;
    constructor(mobilesp)
    {
        super(1,"Nokia",3000);
        this.mobileType=mobilesp;
    }
    printMobileDetails()
    {
        super.printMobileDetails();
        console.log("Mobile Type :"+this.mobileType);
    }
}