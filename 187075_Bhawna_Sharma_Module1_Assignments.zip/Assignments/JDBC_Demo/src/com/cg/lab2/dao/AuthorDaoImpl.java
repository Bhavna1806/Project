package com.cg.lab2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.lab1.pl.DbUtill;
import com.cg.lab2.bean.Author;

public class AuthorDaoImpl implements AuthorDao {
	Connection connect = null;
	private int row;
	private String string;
	PreparedStatement ps = null;

	public int insert(Author a) throws SQLException {
		// TODO Auto-generated method stub
		try {
			connect = DbUtill.getConnection();
			string = "insert into author values(?,?,?,?,?)";
			ps = connect.prepareStatement(string);
			ps.setInt(1, a.getAuthorId());
			ps.setString(2, a.getFirstName());
			ps.setString(3, a.getMiddleName());
			ps.setString(4, a.getLastName());
			ps.setLong(5, a.getPhoneNumber());
			row = ps.executeUpdate();

		} catch (SQLException e) {
			throw e;
		}
		return row;
	}

	public int update(int id, Long phonenumber) throws SQLException {
		// TODO Auto-generated method stub
		try {
			connect = DbUtill.getConnection();
			string = "update author set phonenumber=? where authorid=?";
			ps = connect.prepareStatement(string);
			ps.setLong(1, phonenumber);
			ps.setInt(2, id);
			row = ps.executeUpdate();
		} catch (SQLException e) {
			throw e;
		}
		return row;
	}
}