package com.cg.eis.pl;

public class EmployeeData {

}
