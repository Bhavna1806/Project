package com.cg.eis.Exception;

public class InvalidInputException {

}
