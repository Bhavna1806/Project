
package pl;

import java.util.List;

import bean.Employee;
import service.EmployeeService;

public class EmployeeMain {
	public static void main(String[] args) {
		EmployeeService service = new EmployeeService();
		List<Employee> elist = EmployeeRepository.getEmployees();
		System.out.println("Salary sum : " + service.getSumOfSalary(elist));
		System.out.println("Employees not having Department : ");
		List<Employee> emplist = service.getEmployeeWithoutDept(elist);
		for (Employee e : emplist)
			System.out.println(e);
		System.out.println("Employees not having Manager : ");
		emplist.clear();
		emplist = service.didnotHaveManager(elist);
		for (Employee e : emplist)
			System.out.println(e);
		System.out.println("*************Employee salary has been increased by 15%***********");
		List<String> emplist1 = service.getSalInc(elist);
		for (String e : emplist1)
			System.out.println(e);
		System.out.println("**************Sorted List by First Name*****************");
		emplist.clear();
		emplist = service.sortName(elist);
		for (Employee e : emplist)
			System.out.println(e);
		System.out.println("*********************Sorted List by Employee id*****************");
		emplist.clear();
		emplist = service.sortEmpId(elist);
		for (Employee e : emplist)
			System.out.println(e);
		System.out.println("*******************Sorted List by Department id*****************");
		emplist.clear();
		emplist = service.sortDeptId(elist);
		for (Employee e : emplist)
			System.out.println(e);
	}

}
