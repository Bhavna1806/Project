
package pl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import bean.Department;
import bean.Employee;

public class EmployeeRepository {

	public static List<Department> getDepartments() {
		List<Department> deptlist = new ArrayList<>();
		deptlist.add(new Department(1, "IT", 100));
		deptlist.add(new Department(2, "Sales", 101));
		deptlist.add(new Department(3, "Marketing", 102));
		deptlist.add(new Department(4, "HR", 104));
		return deptlist;
	}

	public static List<Employee> getEmployees() {
		List<Employee> emplist = new ArrayList<>();
		emplist.add(new Employee(100, "Mohit", "Capgemini", "mohit@capgemini.com", "9848022338", LocalDate.of(2012, 5, 25),
				"RECRIUTER", 50000.00, null, new Department(10, "HR", 100)));
		emplist.add(new Employee(104, "Raj", "Capgemini", "raj@capgemini.com", "7894451245", LocalDate.of(2015, 8, 2),
				"TECHNICAL LEADER", 45000.00, 100, null));
		emplist.add(new Employee(105, "Anuj", "Capgemini", "anuj@capgemini.com", "9848032919", LocalDate.of(2015, 8, 2),
				"SALES", 45000.00, null, new Department(20, "Sales", 101)));
		emplist.add(new Employee(101, "Vikas", "Capgemini", "vikas@capgemini.com", "999999999",
				LocalDate.of(2015, 8, 2), "", 45000.00, 100, new Department(40, "Sales", 101)));
		emplist.add(new Employee(102, "Anu", "Capgemini", "anu@capgemini.com", "7787448445",
				LocalDate.of(2011, 7, 21), "Marketing", 15000.00, 100, new Department(30, "Marketing", 102)));
		emplist.add(new Employee(103, "Bhoomi", "Capgemini", "bhoomi@capgemini.com", "874569632",
				LocalDate.of(2010, 8, 2), "Sales_Mgr", 45000.00, 100, null));
		emplist.add(new Employee(106, "Rishabh", "Capgemini", "rishabh@capgemini.com", "8767221020", LocalDate.of(2015, 8, 2),
				"Sales_Mgr", 45000.00, 100, new Department(20, "Sales", 101)));

		return emplist;
	}

}
