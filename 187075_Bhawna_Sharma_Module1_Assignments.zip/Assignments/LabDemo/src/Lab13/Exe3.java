package Lab13;

import java.util.Scanner;

interface lambda1 {
	public boolean print(String a, String b);
}

public class Exe3 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Name ");
		String name = sc.next();
		System.out.println("Enter the Password");
		String pass = sc.next();
		lambda1 l = (a, b) -> {
			if (a.equals(name) && b.equals(pass))
				return true;
			else
				return false;
		};

		boolean c = l.print("Bhavna", "186");

		System.out.println(c);

	}

}
