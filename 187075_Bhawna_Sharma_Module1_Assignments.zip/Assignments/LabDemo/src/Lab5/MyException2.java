package Lab5;

public class MyException2 extends Exception{
	MyException2()
	{
		super("Age of the person should be above 15");
	}

}
