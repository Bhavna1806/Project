package Lab5;

public class MyException1 extends Exception{
	MyException1()
	{
		super("First name or last name cannot be null");
	}

}
