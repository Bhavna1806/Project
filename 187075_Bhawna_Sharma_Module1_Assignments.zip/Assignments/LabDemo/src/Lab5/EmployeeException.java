package Lab5;

public class EmployeeException extends Exception{
	
	
	EmployeeException()
	{
		super("Salary should be more than 3000");
	}

}
