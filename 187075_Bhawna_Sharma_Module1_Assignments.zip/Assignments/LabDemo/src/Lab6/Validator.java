package Lab6;

public class Validator extends Exe7 {
	void Exe7()
	{
		super("First name or the last name cannot be null!!!");
	}

}
