package Lab6;

import Lab5.MyException1;

public class Exe7 {
	public String first_name;
	public String last_name;

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public static void main(String[] args) {
		Exe7 n = new Exe7();
		n.setFirst_name("Bhawna");
		n.setLast_name("Sharma");
		try {
			if ((n.getFirst_name() == null || n.getFirst_name().length() == 0)
					|| (n.getLast_name() == null || n.getLast_name().length() == 0))
				throw new Validator();
		} catch (Validator e) {
			System.out.println(e);
		} finally {
			System.out.println("this is the end");
		}

	}
}
