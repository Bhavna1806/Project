import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MilkyComponent } from './milky.component';

describe('MilkyComponent', () => {
  let component: MilkyComponent;
  let fixture: ComponentFixture<MilkyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MilkyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MilkyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
