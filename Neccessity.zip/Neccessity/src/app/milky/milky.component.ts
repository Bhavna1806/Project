import { Component, OnInit, ResolvedReflectiveFactory } from '@angular/core';
import data from '../milky/Gaal.json'
import { BananaService } from '../banana.service';
import {Router} from '@angular/router'
import { HttpClient } from '../../../node_modules/@angular/common/http';

@Component({
  selector: 'app-milky',
  templateUrl: './milky.component.html',
  styleUrls: ['./milky.component.css']
})
export class MilkyComponent implements OnInit {
  bhawnas = data
  Name
  Password
  constructor(private service: BananaService,private router:Router,private http:HttpClient) { }

  ngOnInit() {
    this.http.get('https://jsonplaceholder.typicode.com/posts').subscribe(res => this.bhawnas = res)
  }
  getdata(Name, Password) {
    // this.service.addition(Password)
    this.router.navigate(['employee'])
  }
 

}
