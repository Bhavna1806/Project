import { Component, OnInit } from '@angular/core';
import data from '../milky/Gaal.json'

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  loginDetails = data
  constructor() { }

  ngOnInit() {
  }

  delete(i) {
    this.loginDetails.splice(i, 1)
  }

}
