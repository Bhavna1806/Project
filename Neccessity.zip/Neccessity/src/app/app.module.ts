import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MilkyComponent } from './milky/milky.component';
import {FormsModule}   from '@angular/forms';
import { LolsPipe } from './lols.pipe';
import { EmployeeComponent } from './employee/employee.component';
import {HttpClientModule} from '@angular/common/http';
import { FormComponent } from './form/form.component';
//import HttpComponent  from './http/http.component';

@NgModule({
  declarations: [
    AppComponent,
    MilkyComponent,
    LolsPipe,
    EmployeeComponent,
    FormComponent
   // HttpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
