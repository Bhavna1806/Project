import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BananaService {

  constructor() { }
  addition(password)
  {
    alert(password+100)
  }
}
