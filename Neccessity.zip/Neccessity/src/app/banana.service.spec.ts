import { TestBed } from '@angular/core/testing';

import { BananaService } from './banana.service';

describe('BananaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BananaService = TestBed.get(BananaService);
    expect(service).toBeTruthy();
  });
});
