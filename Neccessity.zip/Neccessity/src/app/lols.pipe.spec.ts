import { LolsPipe } from './lols.pipe';

describe('LolsPipe', () => {
  it('create an instance', () => {
    const pipe = new LolsPipe();
    expect(pipe).toBeTruthy();
  });
});
